HTMLElement.prototype.action=function(e=new Array){
   this.addEventListener(e[0], e[1]);
}       
var vi=1;

//alert(HTMLElement.prototype.textContent);
var bg_attrs = tx.$get("button");
for(var x = 0;x < bg_attrs.length;x++){
   bga_list = bg_attrs[x].getAttribute("bg");
   if(bga_list == null){
     vi=vi-x;
     var indx = this.index;
     //console.log("Have "+vi+" elements wich dont have the bg attr"+ indx)
   }else{
     //alert(vi + " ,"+ bg_attrs[x].textContent);
     vi++;
     bg_attrs[x].$css(`bg:${bg_attrs[x].getAttribute("bg")};`);
   }
   
  css_list = bg_attrs[x].getAttribute("css");
     if (css_list == null) {
      // vsi = vsi - x;
      // console.log("Have " + vi + " elements wich dont have the bg attr" + indx)
     } else {
       //alert(vi + " ," + bg_attrs[x].textContent);
       //vi++;
       bg_attrs[x].$css(`${bg_attrs[x].getAttribute("css")}`);
     }
}

/*
var class_filtred = tx.$get("button");
for(var h = 0;h < class_filtred.length;h++){
   alert(class_filtred[h].getAttribute("class"));
}*/
//alert(bg_attrs.getAttribute("bg"));*/