ion={
  dz:{
   dragzone : tx.$get('.ion-dragzone'),
   content :tx.$get('.ion-dragzone .ion-content'),
   dzbody:tx.$get('.ion-dragzone .ion-content .ion-dz-body'),
   boardui:tx.$get('.ion-dragzone .ion-content .ion-dz-body .ion-board-ui'),
   anchor:tx.$get('.ion-dragzone .ion-content .ion-dz-body .ion-board-ui .ion-anchor'),   
   dragger:tx.$get('.ion-dragzone .ion-content .ion-dz-body .ion-board-ui input[type=range]')
   
  }
}

for (var i = 0; i < ion.dz.dragzone.length; i++) {
    var anchLeft=ion.dz.anchor[i].offsetLeft;
    var anchTop=ion.dz.anchor[i].offsetTop;
    var boardUiTop=ion.dz.boardui[i].offsetTop;
    
      ion.dz.dragger[i].style.top = anchTop+35+'px';
      ion.dz.dragger[i].style.left = anchLeft-40+'px';
      
  
ion.dz.dragger[i].action(["input", function(){
 
  var drVal = this.value;
  var drValpx  =drVal*2+"px";
  this.parentNode.style.bottom= drValpx;
  this.nextElementSibling.style.background="white";
  this.parentNode.style.height="300px";
  this.parentNode.$css('opacity:1')
  if (this.value >= 90) {
      this.parentNode.style.boxShadow="0px 1px 0px 500px rgba(0,0,0,0.6)";
    this.parentNode.style.height="430px";
  //  this.parentNode.style='opacity:0;';
    
      //this.parentNode.style="visibility:hidden";
    
    console.log(this.parentNode.style.height)
    if(drVal==300){
        this.parentNode.style.bottom=this.value/7.7+"px";
        this.parentNode.style.paddingBottom="190px";
        this.parentNode.$css('opacity:0')
    
      
    }
    
  }else{
    this.parentNode.style.boxShadow="0px 1px 0px 0px rgba(0,0,0,0.6)";
    this.parentNode.style.height="300px";
    this.parentNode.style.bottom=this.value+"px";
    this.parentNode.style.paddingBottom="0px";
     /* if(this.value==0){ 
        this.parentNode.style.height='0px';
      }*/
     
  }
  /*setTimeout(function(){
    console.log(0)=
  this.nextElementSibling.style.transition="0.5s";
  this.nextElementSibling.style.background="#555";
  },700)*/
  
}]);

}
  /*
var app = tx.$get('body')[0];
app.action(['click', function(){
  alert(1)
}])*/



/*
var anchLeft=ion.dz.anchor.offsetLeft;
var anchTop=ion.dz.anchor.offsetTop;
var boardUiTop=ion.dz.boardui.offsetTop;
function reposicion(){
ion.dz.dragger.style.top = anchTop+35+'px';
ion.dz.dragger.style.left = anchLeft-37+'px';
};
reposicion();

ion.dz.dragger.oninput=function(){
  var drVal = this.value;
  var drValpx  =drVal+"px";
  ion.dz.boardui.style.bottom= drValpx;
  ion.dz.anchor.style.background="white";
  setTimeout(function(){
  ion.dz.anchor.style.transition="0.5s";
  ion.dz.anchor.style.background="#555";
  },700)
}

/*
el.grab.onclick=(e)=>{
 // el.rg.style.left="10px";
 var locati$onClick = eval(e.pageX) + "px";
 el.rg.style.left=locationClick;
 console.log(locationClick);
}*/