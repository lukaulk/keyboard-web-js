tx={
$get : function (arg) {
  return document.querySelectorAll(arg)
},
$make: function (arg){
  return document.createElement(arg);
}
}
HTMLElement.prototype.$css=function($csx){
  this.style=$csx.replace("$", "var").replace("bg", "background").replace("var(--clr-lig)","light").replace("size.w","width").replace("size.h", "height").replace("@","rgba");
}
HTMLElement.prototype.add=function(ch){
  this.appendChild(ch);
}